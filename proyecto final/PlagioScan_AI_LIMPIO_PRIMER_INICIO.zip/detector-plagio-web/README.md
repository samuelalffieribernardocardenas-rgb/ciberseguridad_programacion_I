# PlagioScan AI - versión limpia

Esta versión evita los errores de Express porque el backend usa Node.js nativo, sin dependencias externas de Node.

## Levantar con Docker

```bash
docker compose down --remove-orphans
docker compose build --no-cache
docker compose up -d --force-recreate
```

Abrir:

- Frontend: http://localhost:8080
- Backend: http://localhost:3000

## Funciones incluidas

- Subir documentos base en TXT, PDF, DOCX, PNG, JPG, JPEG, BMP y TIFF.
- Analizar documentos contra las bases cargadas.
- OCR para imágenes y PDFs escaneados.
- Extracción de tablas en PDF/DOCX.
- Historial de análisis.
- Análisis borrados.
- Papelera para restaurar o eliminar definitivamente bases y análisis.
- Reporte visual imprimible como PDF.

## Si Docker marca conflicto de nombres

```bash
docker rm -f plagioscan_backend plagioscan_frontend
```

Luego vuelve a levantar.

## Acceso agregado

- En el primer inicio, el sistema solicita crear un usuario, una contraseña y una cuenta de Google de demostración.
- Después del primer registro, siempre muestra la pantalla de inicio de sesión.
- Después de 3 intentos incorrectos, bloquea el acceso durante 28 segundos y muestra un contador.
- La cuenta de Google es únicamente visual; no usa OAuth ni se conecta con Google.
- En **Configuración** se puede cambiar el nombre del programa y el tono de colores.
- Los datos de acceso y personalización se guardan en `backend/data`.

## Funciones incorporadas
- Panel principal con resumen, últimos análisis y conteos.
- Administración de usuarios: búsqueda, roles, activar/desactivar y restablecer contraseña.
- Perfil personal: editar usuario/correo y cambiar contraseña.
- Reporte detallado: similitud, nivel, coincidencias por documento y revisión desde historial.
- Los usuarios normales ven sus propios análisis; el administrador puede revisar todos.
