const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { URL } = require('url');
const crypto = require('crypto');

const PORT = 3000;
const ROOT = __dirname;

const DIRS = {
  uploads: path.join(ROOT, 'uploads'),
  processed: path.join(ROOT, 'processed'),
  base: path.join(ROOT, 'documentos_base'),
  baseOriginal: path.join(ROOT, 'documentos_base_originales'),
  trashBase: path.join(ROOT, 'papelera', 'documentos_base'),
  trashBaseOriginal: path.join(ROOT, 'papelera', 'documentos_base_originales'),
  trashAnalysis: path.join(ROOT, 'papelera', 'analisis'),
  data: path.join(ROOT, 'data')
};

const files = {
  bases: path.join(ROOT, 'bases.json'),
  history: path.join(ROOT, 'historial.json'),
  trash: path.join(ROOT, 'papelera.json'),
  auth: path.join(DIRS.data, 'auth.json'),
  users: path.join(DIRS.data, 'users.json'),
  config: path.join(DIRS.data, 'config.json')
};

Object.values(DIRS).forEach(d => fs.mkdirSync(d, { recursive: true }));

const allowed = ['.txt', '.pdf', '.docx', '.png', '.jpg', '.jpeg', '.bmp', '.tiff'];

function send(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function readJSON(f, fallback) {
  try {
    return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(f, data) {
  fs.writeFileSync(f, JSON.stringify(data, null, 2), 'utf8');
}

function id() {
  return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

function safeName(n) {
  return path.basename(n || 'archivo').replace(/[^a-zA-Z0-9._-]/g, '_');
}

function extName(n) {
  return path.extname(n || '').toLowerCase();
}

function execAsync(cmd, args) {
  return new Promise((resolve, reject) =>
    execFile(cmd, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) =>
      err ? reject({ err, stdout, stderr }) : resolve({ stdout, stderr })
    )
  );
}

function bodyBuffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function jsonBody(req) {
  const buf = await bodyBuffer(req);

  if (!buf.length) {
    return {};
  }

  try {
    return JSON.parse(buf.toString('utf8'));
  } catch {
    throw new Error('El cuerpo JSON no es válido');
  }
}

const sessions = new Map();
const SESSION_MS = 12 * 60 * 60 * 1000;
const LOCK_SECONDS = 28;
const MAX_LOGIN_ATTEMPTS = 3;
const tones = ['violet', 'blue', 'green', 'orange', 'pink'];

function defaultConfig() {
  return { appName: 'PlagioScan AI', tone: 'violet' };
}

function getConfig() {
  const cfg = readJSON(files.config, defaultConfig());
  return {
    appName: typeof cfg.appName === 'string' && cfg.appName.trim()
      ? cfg.appName.trim().slice(0, 40)
      : defaultConfig().appName,
    tone: tones.includes(cfg.tone) ? cfg.tone : defaultConfig().tone
  };
}

function normalizeUsername(value) {
  return String(value || '').trim();
}

function getUsers() {
  let users = readJSON(files.users, []);
  if (!Array.isArray(users)) users = [];

  // Migración automática desde la versión antigua de una sola cuenta.
  if (!users.length) {
    const legacy = readJSON(files.auth, null);
    if (legacy && legacy.username && legacy.passwordHash && legacy.passwordSalt) {
      users = [{
        id: id(),
        username: legacy.username,
        googleEmail: legacy.googleEmail || '',
        role: 'admin',
        passwordSalt: legacy.passwordSalt,
        passwordHash: legacy.passwordHash,
        failedAttempts: legacy.failedAttempts || 0,
        lockUntil: legacy.lockUntil || 0,
        createdAt: legacy.createdAt || new Date().toISOString(),
        lastLoginAt: null,
        active: true
      }];
      saveJSON(files.users, users);
    }
  }

  return users;
}

function saveUsers(users) {
  saveJSON(files.users, users);
}

function hashPassword(password, salt) {
  return crypto.scryptSync(String(password), salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
}

function safeEqualHex(a, b) {
  try {
    const ab = Buffer.from(a, 'hex');
    const bb = Buffer.from(b, 'hex');
    return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
  } catch {
    return false;
  }
}

function bearerToken(req) {
  const value = req.headers.authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(value);
  return match ? match[1] : '';
}

function activeSession(req) {
  const token = bearerToken(req);
  const session = sessions.get(token);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    sessions.delete(token);
    return null;
  }

  const user = getUsers().find(u => u.id === session.userId && u.active !== false);
  if (!user) {
    sessions.delete(token);
    return null;
  }

  session.expiresAt = Date.now() + SESSION_MS;
  return { token, ...session, user };
}

function requireAuth(req, res) {
  const session = activeSession(req);
  if (!session) {
    send(res, 401, { error: 'Sesión no válida. Inicia sesión nuevamente.' });
    return null;
  }
  return session;
}

function requireAdmin(session, res) {
  if (!session || session.user.role !== 'admin') {
    send(res, 403, { error: 'Esta función está disponible solo para administradores.' });
    return false;
  }
  return true;
}

function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    googleEmail: user.googleEmail || '',
    role: user.role || 'user',
    createdAt: user.createdAt || null,
    lastLoginAt: user.lastLoginAt || null,
    active: user.active !== false
  };
}

function validateAccountInput(body, isSetup = false) {
  const username = normalizeUsername(body.username);
  const password = String(body.password || '');
  const googleEmail = String(body.googleEmail || '').trim().toLowerCase();

  if (!/^[a-zA-Z0-9._-]{3,30}$/.test(username)) {
    throw new Error('El usuario debe tener entre 3 y 30 caracteres y usar solo letras, números, punto, guion o guion bajo.');
  }
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    throw new Error('La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número.');
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(googleEmail)) {
    throw new Error('Ingresa un correo electrónico válido.');
  }
  return { username, password, googleEmail, role: isSetup ? 'admin' : 'user' };
}

function createStoredUser(data) {
  const salt = crypto.randomBytes(16).toString('hex');
  return {
    id: id(),
    username: data.username,
    googleEmail: data.googleEmail,
    role: data.role,
    passwordSalt: salt,
    passwordHash: hashPassword(data.password, salt),
    failedAttempts: 0,
    lockUntil: 0,
    createdAt: new Date().toISOString(),
    lastLoginAt: null,
    active: true
  };
}

async function setupAccount(req, res) {
  const users = getUsers();
  if (users.length) return send(res, 409, { error: 'La cuenta administradora ya fue creada.' });

  let data;
  try { data = validateAccountInput(await jsonBody(req), true); }
  catch (e) { return send(res, 400, { error: e.message }); }

  const user = createStoredUser(data);
  users.push(user);
  saveUsers(users);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: user.id, expiresAt: Date.now() + SESSION_MS });
  return send(res, 201, { ok: true, token, user: publicUser(user), config: getConfig() });
}

async function register(req, res) {
  const users = getUsers();
  if (!users.length) return send(res, 428, { error: 'Primero debe crearse la cuenta administradora.', setupRequired: true });

  let data;
  try { data = validateAccountInput(await jsonBody(req), false); }
  catch (e) { return send(res, 400, { error: e.message }); }

  const exists = users.some(u => u.username.toLowerCase() === data.username.toLowerCase() || u.googleEmail.toLowerCase() === data.googleEmail);
  if (exists) return send(res, 409, { error: 'El nombre de usuario o correo ya está registrado.' });

  const user = createStoredUser(data);
  users.push(user);
  saveUsers(users);
  return send(res, 201, { ok: true, message: 'Cuenta creada correctamente. Ya puedes iniciar sesión.' });
}

async function login(req, res) {
  const users = getUsers();
  if (!users.length) return send(res, 428, { error: 'Primero debes crear la cuenta administradora.', setupRequired: true });

  const body = await jsonBody(req);
  const username = normalizeUsername(body.username);
  const password = String(body.password || '');
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

  if (!user || user.active === false) {
    return send(res, 401, { error: 'Usuario o contraseña incorrectos.' });
  }

  const now = Date.now();
  if (Number(user.lockUntil || 0) > now) {
    return send(res, 423, { error: 'Cuenta bloqueada temporalmente.', locked: true, remainingSeconds: Math.max(1, Math.ceil((user.lockUntil - now) / 1000)) });
  }
  if (user.lockUntil && user.lockUntil <= now) {
    user.lockUntil = 0;
    user.failedAttempts = 0;
  }

  const valid = safeEqualHex(hashPassword(password, user.passwordSalt), user.passwordHash);
  if (!valid) {
    user.failedAttempts = Number(user.failedAttempts || 0) + 1;
    if (user.failedAttempts >= MAX_LOGIN_ATTEMPTS) {
      user.failedAttempts = 0;
      user.lockUntil = Date.now() + LOCK_SECONDS * 1000;
      saveUsers(users);
      return send(res, 423, { error: 'Has alcanzado el límite de intentos.', locked: true, remainingSeconds: LOCK_SECONDS });
    }
    saveUsers(users);
    return send(res, 401, { error: 'Usuario o contraseña incorrectos.', attemptsRemaining: MAX_LOGIN_ATTEMPTS - user.failedAttempts });
  }

  user.failedAttempts = 0;
  user.lockUntil = 0;
  user.lastLoginAt = new Date().toISOString();
  saveUsers(users);

  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId: user.id, expiresAt: Date.now() + SESSION_MS });
  return send(res, 200, { ok: true, token, user: publicUser(user), config: getConfig() });
}

function logout(req, res) {
  const token = bearerToken(req);
  if (token) sessions.delete(token);
  return send(res, 200, { ok: true });
}

function userStats() {
  const users = getUsers();
  return {
    total: users.length,
    admins: users.filter(u => u.role === 'admin').length,
    regular: users.filter(u => u.role !== 'admin').length,
    active: users.filter(u => u.active !== false).length
  };
}

async function updateConfig(req, res) {
  const body = await jsonBody(req);
  const current = getConfig();
  const appName = String(body.appName ?? current.appName).trim();
  const tone = String(body.tone ?? current.tone);
  if (appName.length < 2 || appName.length > 40) return send(res, 400, { error: 'El nombre del programa debe tener entre 2 y 40 caracteres.' });
  if (!tones.includes(tone)) return send(res, 400, { error: 'El tono seleccionado no es válido.' });
  const config = { appName, tone };
  saveJSON(files.config, config);
  return send(res, 200, config);
}

function parseMultipart(buf, contentType) {
  const m = /boundary=(?:(?:"([^"]+)")|([^;]+))/i.exec(contentType || '');

  if (!m) {
    throw new Error('No se encontró boundary multipart');
  }

  const boundary = Buffer.from('--' + (m[1] || m[2]));
  const parts = [];

  let start = buf.indexOf(boundary);

  while (start !== -1) {
    start += boundary.length;

    if (buf[start] === 45 && buf[start + 1] === 45) {
      break;
    }

    if (buf[start] === 13 && buf[start + 1] === 10) {
      start += 2;
    }

    const headerEnd = buf.indexOf(Buffer.from('\r\n\r\n'), start);

    if (headerEnd === -1) {
      break;
    }

    const header = buf.slice(start, headerEnd).toString('utf8');
    const dataStart = headerEnd + 4;
    const next = buf.indexOf(boundary, dataStart);

    if (next === -1) {
      break;
    }

    const dataEnd = next - 2;
    const content = buf.slice(dataStart, Math.max(dataStart, dataEnd));

    const name = /name="([^"]+)"/.exec(header)?.[1];
    const filename = /filename="([^"]*)"/.exec(header)?.[1];

    parts.push({ name, filename, content, header });

    start = next;
  }

  return parts;
}

async function receiveFile(req, field = 'documento') {
  const buf = await bodyBuffer(req);
  const parts = parseMultipart(buf, req.headers['content-type']);

  const part = parts.find(p => p.name === field && p.filename);

  if (!part) {
    throw new Error('No se recibió archivo');
  }

  const original = safeName(part.filename);
  const ext = extName(original);

  if (!allowed.includes(ext)) {
    throw new Error('Formato no permitido. Usa TXT, PDF, DOCX o imagen.');
  }

  const filename = `${Date.now()}-${original}`;
  const dest = path.join(DIRS.uploads, filename);

  fs.writeFileSync(dest, part.content);

  return {
    original,
    ext,
    path: dest,
    filename,
    size: part.content.length
  };
}

async function extract(filePath) {
  const { stdout, stderr } = await execAsync('python3', [
    path.join(ROOT, 'document_processor.py'),
    filePath
  ]);

  let data;

  try {
    data = JSON.parse(stdout);
  } catch {
    throw new Error('El procesador no devolvió JSON. ' + stderr);
  }

  if (data.error) {
    throw new Error(data.error);
  }

  return data;
}

async function runCpp(txtPath) {
  const bin = path.join(ROOT, 'cpp-engine', 'plagio');
  const { stdout } = await execAsync(bin, [txtPath, DIRS.base]);

  const data = JSON.parse(stdout);

  if (data.error) {
    throw new Error(data.error);
  }

  return data;
}

function listActiveBases() {
  return readJSON(files.bases, []).filter(x => !x.deleted);
}

function stats() {
  const hist = readJSON(files.history, []).filter(x => !x.deleted);

  const risk = {
    Bajo: 0,
    Moderado: 0,
    Alto: 0,
    Crítico: 0
  };

  const types = {};

  for (const h of hist) {
    if (risk[h.nivelRiesgo] !== undefined) {
      risk[h.nivelRiesgo]++;
    }

    const t = h.tipoDocumento || 'OTRO';
    types[t] = (types[t] || 0) + 1;
  }

  const avg = hist.length
    ? hist.reduce((a, b) => a + Number(b.resultadoGeneral || 0), 0) / hist.length
    : 0;

  return {
    resumen: {
      totalAnalizados: hist.length,
      promedioSimilitud: Number(avg.toFixed(2)),
      criticos: risk['Crítico'],
      riesgo: risk,
      tipos: types
    },
    historial: hist.slice(0, 10),
    bases: listActiveBases().length
  };
}

/*
  FUNCIÓN CORREGIDA:
  Antes usaba solo fs.renameSync().
  En Docker puede salir el error EXDEV cuando se mueve entre volúmenes.
  Ahora primero intenta mover; si falla por EXDEV, copia y luego borra.
*/
function moveIfExists(from, to) {
  fs.mkdirSync(path.dirname(to), { recursive: true });

  if (fs.existsSync(from)) {
    try {
      fs.renameSync(from, to);
    } catch (err) {
      if (err.code === 'EXDEV') {
        fs.copyFileSync(from, to);
        fs.unlinkSync(from);
      } else {
        throw err;
      }
    }
  }
}

async function uploadBase(req, res) {
  const f = await receiveFile(req);
  const extraction = await extract(f.path);

  if (!extraction.extracted_text || !extraction.extracted_text.trim()) {
    throw new Error('No se pudo extraer texto útil del documento base.');
  }

  const itemId = id();
  const originalPath = path.join(DIRS.baseOriginal, `${itemId}-${f.original}`);

  moveIfExists(f.path, originalPath);

  const processedName = `${itemId}-${path.parse(f.original).name}.txt`;
  const processedPath = path.join(DIRS.base, processedName);

  fs.writeFileSync(processedPath, extraction.extracted_text, 'utf8');

  const bases = readJSON(files.bases, []);

  const item = {
    id: itemId,
    nombre: f.original,
    tipo: f.ext.replace('.', '').toUpperCase(),
    fecha: new Date().toISOString(),
    processedName,
    originalName: path.basename(originalPath),
    palabras: extraction.metadata.palabras_extraidas || 0,
    visual: extraction.metadata,
    deleted: false
  };

  bases.unshift(item);
  saveJSON(files.bases, bases);

  send(res, 200, {
    ok: true,
    documento: item
  });
}

async function analyze(req, res, session) {
  const f = await receiveFile(req);
  const extraction = await extract(f.path);

  if (!extraction.extracted_text || !extraction.extracted_text.trim()) {
    throw new Error('No se pudo extraer texto útil del archivo analizado.');
  }

  const txt = path.join(DIRS.processed, `${Date.now()}-analisis.txt`);

  fs.writeFileSync(txt, extraction.extracted_text, 'utf8');

  const result = await runCpp(txt);

  try {
    fs.unlinkSync(txt);
  } catch {}

  const hist = readJSON(files.history, []);

  const h = {
    id: id(),
    fecha: new Date().toISOString(),
    documento: f.original,
    tipoDocumento: f.ext.replace('.', '').toUpperCase(),
    resultadoGeneral: result.resultadoGeneral,
    nivelRiesgo: result.nivelRiesgo,
    motor: result.motor,
    visual: extraction.metadata,
    comparaciones: result.comparaciones,
    userId: session.user.id,
    userName: session.user.username,
    deleted: false
  };

  hist.unshift(h);
  saveJSON(files.history, hist);

  result.documentoAnalizado = f.original;
  result.tipoDocumento = h.tipoDocumento;
  result.visual = extraction.metadata;
  result.id = h.id;
  result.resumenSistema = stats().resumen;

  send(res, 200, result);
}

function deleteBase(req, res, idv) {
  const bases = readJSON(files.bases, []);
  const item = bases.find(x => x.id === idv);

  if (!item) {
    return send(res, 404, { error: 'Base no encontrada' });
  }

  item.deleted = true;
  item.deletedAt = new Date().toISOString();

  moveIfExists(
    path.join(DIRS.base, item.processedName),
    path.join(DIRS.trashBase, item.processedName)
  );

  moveIfExists(
    path.join(DIRS.baseOriginal, item.originalName),
    path.join(DIRS.trashBaseOriginal, item.originalName)
  );

  saveJSON(files.bases, bases);

  send(res, 200, { ok: true });
}

function restoreBase(req, res, idv) {
  const bases = readJSON(files.bases, []);
  const item = bases.find(x => x.id === idv);

  if (!item) {
    return send(res, 404, { error: 'Base no encontrada' });
  }

  item.deleted = false;
  delete item.deletedAt;

  moveIfExists(
    path.join(DIRS.trashBase, item.processedName),
    path.join(DIRS.base, item.processedName)
  );

  moveIfExists(
    path.join(DIRS.trashBaseOriginal, item.originalName),
    path.join(DIRS.baseOriginal, item.originalName)
  );

  saveJSON(files.bases, bases);

  send(res, 200, { ok: true });
}

function deleteAnalysis(req, res, idv) {
  const hist = readJSON(files.history, []);
  const h = hist.find(x => x.id === idv);

  if (!h) {
    return send(res, 404, { error: 'Análisis no encontrado' });
  }

  h.deleted = true;
  h.deletedAt = new Date().toISOString();

  saveJSON(files.history, hist);

  send(res, 200, { ok: true });
}

function restoreAnalysis(req, res, idv) {
  const hist = readJSON(files.history, []);
  const h = hist.find(x => x.id === idv);

  if (!h) {
    return send(res, 404, { error: 'Análisis no encontrado' });
  }

  h.deleted = false;
  delete h.deletedAt;

  saveJSON(files.history, hist);

  send(res, 200, { ok: true });
}

function emptyItem(req, res, type, idv) {
  if (type === 'base') {
    let bases = readJSON(files.bases, []);
    const item = bases.find(x => x.id === idv);

    if (item) {
      try {
        fs.unlinkSync(path.join(DIRS.trashBase, item.processedName));
      } catch {}

      try {
        fs.unlinkSync(path.join(DIRS.trashBaseOriginal, item.originalName));
      } catch {}
    }

    bases = bases.filter(x => x.id !== idv);
    saveJSON(files.bases, bases);

    return send(res, 200, { ok: true });
  }

  if (type === 'analisis') {
    let hist = readJSON(files.history, []);
    hist = hist.filter(x => x.id !== idv);
    saveJSON(files.history, hist);

    return send(res, 200, { ok: true });
  }

  send(res, 400, { error: 'Tipo no válido' });
}

async function updateOwnProfile(req, res, session) {
  const body = await jsonBody(req);
  const users = getUsers();
  const user = users.find(u => u.id === session.user.id);
  if (!user) return send(res, 404, { error: 'Usuario no encontrado.' });
  const username = normalizeUsername(body.username);
  const googleEmail = String(body.googleEmail || '').trim().toLowerCase();
  if (!/^[a-zA-Z0-9._-]{3,30}$/.test(username)) return send(res, 400, { error: 'Usuario no válido.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(googleEmail)) return send(res, 400, { error: 'Correo no válido.' });
  if (users.some(u => u.id !== user.id && (u.username.toLowerCase() === username.toLowerCase() || u.googleEmail.toLowerCase() === googleEmail))) return send(res, 409, { error: 'El usuario o correo ya está registrado.' });
  user.username = username; user.googleEmail = googleEmail;
  saveUsers(users);
  return send(res, 200, { user: publicUser(user) });
}

async function changeOwnPassword(req, res, session) {
  const body = await jsonBody(req);
  const users = getUsers();
  const user = users.find(u => u.id === session.user.id);
  const current = String(body.currentPassword || '');
  const next = String(body.newPassword || '');
  if (!safeEqualHex(hashPassword(current, user.passwordSalt), user.passwordHash)) return send(res, 400, { error: 'La contraseña actual no es correcta.' });
  if (next.length < 8 || !/[A-Z]/.test(next) || !/[a-z]/.test(next) || !/\d/.test(next)) return send(res, 400, { error: 'La nueva contraseña debe tener 8 caracteres, mayúscula, minúscula y número.' });
  const salt = crypto.randomBytes(16).toString('hex');
  user.passwordSalt = salt; user.passwordHash = hashPassword(next, salt);
  saveUsers(users);
  for (const [token, value] of sessions) if (value.userId === user.id && token !== session.token) sessions.delete(token);
  return send(res, 200, { ok: true });
}

async function updateAdminUser(req, res, session, userId) {
  const body = await jsonBody(req);
  const users = getUsers();
  const target = users.find(u => u.id === userId);
  if (!target) return send(res, 404, { error: 'Usuario no encontrado.' });
  if (target.id === session.user.id && body.active === false) return send(res, 400, { error: 'No puedes desactivar tu propia cuenta.' });
  if (target.id === session.user.id && body.role && body.role !== 'admin') return send(res, 400, { error: 'No puedes quitarte tu propio rol de administrador.' });
  if (body.role && ['admin','user'].includes(body.role)) target.role = body.role;
  if (typeof body.active === 'boolean') target.active = body.active;
  saveUsers(users);
  if (target.active === false) for (const [token, value] of sessions) if (value.userId === target.id) sessions.delete(token);
  return send(res, 200, { user: publicUser(target), stats: userStats() });
}

async function adminResetPassword(req, res, session, userId) {
  const body = await jsonBody(req);
  const users = getUsers();
  const target = users.find(u => u.id === userId);
  if (!target) return send(res, 404, { error: 'Usuario no encontrado.' });
  const password = String(body.password || '');
  if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) return send(res, 400, { error: 'La contraseña temporal no cumple los requisitos.' });
  const salt = crypto.randomBytes(16).toString('hex');
  target.passwordSalt = salt; target.passwordHash = hashPassword(password, salt); target.failedAttempts = 0; target.lockUntil = 0;
  saveUsers(users);
  for (const [token, value] of sessions) if (value.userId === target.id) sessions.delete(token);
  return send(res, 200, { ok: true });
}

function dashboard(session) {
  const all = readJSON(files.history, []).filter(x => !x.deleted);
  const visible = session.user.role === 'admin' ? all : all.filter(x => !x.userId || x.userId === session.user.id);
  const avg = visible.length ? visible.reduce((a,b)=>a+Number(b.resultadoGeneral||0),0)/visible.length : 0;
  return {
    totalAnalizados: visible.length,
    documentosBase: listActiveBases().length,
    promedioSimilitud: Number(avg.toFixed(2)),
    coincidenciasDetectadas: visible.reduce((n,h)=>n+(h.comparaciones||[]).reduce((a,c)=>a+Number(c.coincidencias||0),0),0),
    usuariosRegistrados: session.user.role === 'admin' ? getUsers().length : null,
    recientes: visible.slice(0,5)
  };
}

async function router(req, res) {
  if (req.method === 'OPTIONS') {
    return send(res, 200, { ok: true });
  }

  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;

  try {
    if (req.method === 'GET' && p === '/api/health') {
      return send(res, 200, {
        estado: 'activo',
        nombre: `${getConfig().appName} Backend`
      });
    }

    if (req.method === 'GET' && p === '/api/auth/status') {
      const users = getUsers();
      return send(res, 200, { setupRequired: users.length === 0, registrationEnabled: users.length > 0, config: getConfig() });
    }

    if (req.method === 'POST' && p === '/api/auth/setup') {
      return await setupAccount(req, res);
    }

    if (req.method === 'POST' && p === '/api/auth/login') {
      return await login(req, res);
    }

    if (req.method === 'POST' && p === '/api/auth/register') {
      return await register(req, res);
    }

    if (req.method === 'POST' && p === '/api/auth/logout') {
      return logout(req, res);
    }
    if (req.method === 'GET' && p === '/') {
      return send(res, 200, {
        nombre: `${getConfig().appName} Backend`,
        estado: 'activo',
        sinDependenciasNode: true,
        formatos: allowed
      });
    }

    let m;
    let session = null;
    if (p.startsWith('/api/')) {
      session = requireAuth(req, res);
      if (!session) return;
    }

    if (req.method === 'GET' && p === '/api/auth/me') {
      return send(res, 200, { user: publicUser(session.user), config: getConfig() });
    }

    if (req.method === 'PUT' && p === '/api/profile') return await updateOwnProfile(req, res, session);
    if (req.method === 'PUT' && p === '/api/profile/password') return await changeOwnPassword(req, res, session);
    if (req.method === 'GET' && p === '/api/dashboard') return send(res, 200, dashboard(session));

    if (req.method === 'GET' && p === '/api/admin/users') {
      if (!requireAdmin(session, res)) return;
      return send(res, 200, { users: getUsers().map(publicUser), stats: userStats() });
    }

    if ((m = /^\/api\/admin\/users\/([^/]+)$/.exec(p)) && req.method === 'PUT') {
      if (!requireAdmin(session, res)) return;
      return await updateAdminUser(req, res, session, m[1]);
    }
    if ((m = /^\/api\/admin\/users\/([^/]+)\/password$/.exec(p)) && req.method === 'PUT') {
      if (!requireAdmin(session, res)) return;
      return await adminResetPassword(req, res, session, m[1]);
    }

    if (req.method === 'GET' && p === '/api/config') {
      return send(res, 200, getConfig());
    }

    if (req.method === 'PUT' && p === '/api/config') {
      if (!requireAdmin(session, res)) return;
      return await updateConfig(req, res);
    }

    if (req.method === 'GET' && p === '/api/documentos-base') {
      return send(res, 200, listActiveBases());
    }

    if (req.method === 'POST' && p === '/api/documentos-base') {
      return await uploadBase(req, res);
    }


    if ((m = /^\/api\/documentos-base\/([^/]+)$/.exec(p)) && req.method === 'DELETE') {
      return deleteBase(req, res, m[1]);
    }

    if ((m = /^\/api\/documentos-base\/([^/]+)\/restaurar$/.exec(p)) && req.method === 'POST') {
      return restoreBase(req, res, m[1]);
    }

    if (req.method === 'POST' && p === '/api/analizar') {
      return await analyze(req, res, session);
    }

    if (req.method === 'GET' && p === '/api/historial') {
      const all = readJSON(files.history, []).filter(x => !x.deleted);
      const visible = session.user.role === 'admin' ? all : all.filter(x => !x.userId || x.userId === session.user.id);
      return send(res, 200, visible);
    }

    if ((m = /^\/api\/historial\/([^/]+)$/.exec(p)) && req.method === 'DELETE') {
      return deleteAnalysis(req, res, m[1]);
    }

    if ((m = /^\/api\/historial\/([^/]+)\/restaurar$/.exec(p)) && req.method === 'POST') {
      return restoreAnalysis(req, res, m[1]);
    }

    if (req.method === 'GET' && p === '/api/estadisticas') {
      return send(res, 200, stats());
    }

    if (req.method === 'GET' && p === '/api/papelera') {
      return send(res, 200, {
        bases: readJSON(files.bases, []).filter(x => x.deleted),
        analisis: readJSON(files.history, []).filter(x => x.deleted)
      });
    }

    if (req.method === 'GET' && p === '/api/analisis-borrados') {
      return send(res, 200, readJSON(files.history, []).filter(x => x.deleted));
    }

    if ((m = /^\/api\/papelera\/(base|analisis)\/([^/]+)\/restaurar$/.exec(p)) && req.method === 'POST') {
      return m[1] === 'base'
        ? restoreBase(req, res, m[2])
        : restoreAnalysis(req, res, m[2]);
    }

    if ((m = /^\/api\/papelera\/(base|analisis)\/([^/]+)$/.exec(p)) && req.method === 'DELETE') {
      return emptyItem(req, res, m[1], m[2]);
    }

    return send(res, 404, { error: 'Ruta no encontrada' });

  } catch (e) {
    console.error(e);
    return send(res, 500, {
      error: e.message || 'Error interno'
    });
  }
}

http.createServer(router).listen(PORT, () => {
  console.log(`PlagioScan backend activo en http://localhost:${PORT}`);
});
