#!/usr/bin/env python3
import io, json, re, sys
from pathlib import Path
try:
    import fitz
    import pdfplumber
    import pytesseract
    from PIL import Image
    from docx import Document
except Exception as e:
    print(json.dumps({"error": "Faltan librerías Python: " + str(e)})); sys.exit(1)

def clean(t): return re.sub(r"\s+", " ", (t or "").replace("\x00", " ")).strip()
def count_words(t): return len([w for w in re.split(r"\s+", t.strip()) if w])
def safe_read(p):
    for enc in ("utf-8","latin-1","cp1252"):
        try: return p.read_text(encoding=enc)
        except Exception: pass
    return ""
def ocr(img):
    try: return clean(pytesseract.image_to_string(img))
    except Exception: return ""
def txt(p):
    text=clean(safe_read(p)); return text,{"tipo_documento":"TXT","paginas":1,"imagenes_detectadas":0,"tablas_detectadas":0,"ocr_aplicado":False,"paginas_con_ocr":0,"palabras_extraidas":count_words(text),"caracteres_extraidos":len(text),"resumen_visual":"Archivo de texto plano."}
def image(p):
    img=Image.open(p); text=ocr(img); return text,{"tipo_documento":p.suffix[1:].upper(),"paginas":1,"imagenes_detectadas":1,"tablas_detectadas":0,"ocr_aplicado":True,"paginas_con_ocr":1,"palabras_extraidas":count_words(text),"caracteres_extraidos":len(text),"resumen_visual":"Imagen procesada con OCR para extraer texto visible."}
def docx(p):
    d=Document(str(p)); parts=[]
    for para in d.paragraphs:
        if para.text.strip(): parts.append(para.text)
    tables=0
    for tb in d.tables:
        tables+=1
        for row in tb.rows:
            vals=[clean(c.text) for c in row.cells if clean(c.text)]
            if vals: parts.append(" | ".join(vals))
    text=clean("\n".join(parts)); imgs=len(getattr(d,"inline_shapes",[]))
    return text,{"tipo_documento":"DOCX","paginas":None,"imagenes_detectadas":imgs,"tablas_detectadas":tables,"ocr_aplicado":False,"paginas_con_ocr":0,"palabras_extraidas":count_words(text),"caracteres_extraidos":len(text),"resumen_visual":f"Word procesado: {tables} tabla(s), {imgs} imagen(es)."}
def pdf(p):
    texts=[]; tables=0; imgs=0; ocr_pages=0; ocr_used=False
    try:
        with pdfplumber.open(str(p)) as pdfp:
            for page in pdfp.pages:
                t=page.extract_text() or ""
                if t.strip(): texts.append(t)
                try: extracted=page.extract_tables() or []
                except Exception: extracted=[]
                for tb in extracted:
                    tables+=1
                    for row in tb:
                        vals=[clean(c or "") for c in row if clean(c or "")]
                        if vals: texts.append(" | ".join(vals))
    except Exception: pass
    doc=fitz.open(str(p)); pages=doc.page_count
    for i in range(pages):
        pg=doc.load_page(i); imgs += len(pg.get_images(full=True)); plain=pg.get_text("text").strip()
        if (not plain) or pg.get_images(full=True):
            try:
                pix=pg.get_pixmap(matrix=fitz.Matrix(1.6,1.6), alpha=False)
                im=Image.open(io.BytesIO(pix.tobytes("png")))
                ot=ocr(im)
                if ot:
                    texts.append(ot); ocr_pages+=1; ocr_used=True
            except Exception: pass
    text=clean("\n".join(texts))
    return text,{"tipo_documento":"PDF","paginas":pages,"imagenes_detectadas":imgs,"tablas_detectadas":tables,"ocr_aplicado":ocr_used,"paginas_con_ocr":ocr_pages,"palabras_extraidas":count_words(text),"caracteres_extraidos":len(text),"resumen_visual":f"PDF procesado: {pages} página(s), {tables} tabla(s), {imgs} imagen(es)."}
def main():
    if len(sys.argv)<2: print(json.dumps({"error":"Falta archivo"})); sys.exit(1)
    p=Path(sys.argv[1]); ext=p.suffix.lower()
    try:
        if ext==".txt": text,meta=txt(p)
        elif ext==".pdf": text,meta=pdf(p)
        elif ext==".docx": text,meta=docx(p)
        elif ext in [".png",".jpg",".jpeg",".bmp",".tiff"]: text,meta=image(p)
        else: print(json.dumps({"error":"Formato no soportado: "+ext})); sys.exit(1)
        print(json.dumps({"extracted_text":text,"metadata":meta}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error":str(e)})); sys.exit(1)
if __name__=="__main__": main()
