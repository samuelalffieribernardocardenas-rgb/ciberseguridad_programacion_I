const API_URL = ''; // El backend se accede mediante el proxy interno de Nginx
const TOKEN_KEY = 'plagioscan_session_token';
const USER_KEY = 'plagioscan_last_user';

const authScreen = document.getElementById('authScreen');
const authCard = document.getElementById('authCard');
const appRoot = document.getElementById('appRoot');
const contenido = document.getElementById('contenido');

let ultimoResultado = null;
let usuarioActual = null;
let configuracionActual = { appName: 'PlagioScan AI', tone: 'violet' };
let lockTimer = null;

function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function getToken() {
  return localStorage.getItem(TOKEN_KEY) || '';
}

function saveToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request(path, options = {}, authenticated = true) {
  const headers = new Headers(options.headers || {});
  const requestOptions = { ...options, headers };

  if (authenticated && getToken()) {
    headers.set('Authorization', `Bearer ${getToken()}`);
  }

  if (requestOptions.body && !(requestOptions.body instanceof FormData) && typeof requestOptions.body !== 'string') {
    headers.set('Content-Type', 'application/json');
    requestOptions.body = JSON.stringify(requestOptions.body);
  }

  // Evita que la pantalla inicial quede cargando indefinidamente si el backend no responde.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);
  requestOptions.signal = controller.signal;

  let response;
  try {
    response = await fetch(API_URL + path, requestOptions);
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error('El backend tardó demasiado en responder. Reinicia los contenedores e inténtalo nuevamente.');
    }
    throw new Error('No se pudo conectar con el backend. Verifica que Docker esté ejecutando ambos contenedores.');
  } finally {
    clearTimeout(timeoutId);
  }

  const data = await response.json().catch(() => ({ error: 'Respuesta no válida del servidor.' }));

  if (!response.ok) {
    const error = new Error(data.error || 'Ocurrió un error.');
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
}

function api(path, options = {}) {
  return request(path, options, true);
}

function publicApi(path, options = {}) {
  return request(path, options, false);
}

function applyConfig(config = {}) {
  configuracionActual = {
    appName: String(config.appName || 'PlagioScan AI'),
    tone: String(config.tone || 'violet')
  };

  document.body.dataset.tone = configuracionActual.tone;
  document.title = configuracionActual.appName;

  const brand = document.getElementById('brandName');
  const topbar = document.getElementById('topbarName');
  if (brand) brand.textContent = configuracionActual.appName;
  if (topbar) topbar.textContent = configuracionActual.appName;
  const authBrand = document.getElementById('authBrandName');
  if (authBrand) authBrand.textContent = configuracionActual.appName;
}

function showAuth() {
  appRoot.classList.add('hidden');
  authScreen.classList.remove('hidden');
}

function showApp() {
  authScreen.classList.add('hidden');
  appRoot.classList.remove('hidden');
}

function setAuthError(message) {
  const box = document.getElementById('authError');
  if (!box) return;
  box.textContent = message || '';
  box.classList.toggle('show', Boolean(message));
}

function setAuthBusy(busy, text = 'Procesando…') {
  const button = document.getElementById('authSubmit');
  if (!button) return;
  button.disabled = busy;
  button.dataset.originalText ||= button.textContent;
  button.textContent = busy ? text : button.dataset.originalText;
}

function renderSetup() {
  clearInterval(lockTimer);
  const lastUser = localStorage.getItem(USER_KEY) || '';

  authCard.innerHTML = `
    <h1>Crear cuenta principal</h1>
    <p class="auth-subtitle">Configura la primera cuenta del sistema.</p>
    <div class="auth-divider"></div>
    <form class="auth-form" id="setupForm">
      <label class="auth-label">Nombre de usuario
        <span class="auth-input-wrap"><span>U</span><input class="auth-input" id="setupUser" maxlength="30" value="${esc(lastUser)}" placeholder="Ejemplo: Samuel" required></span>
      </label>
      <label class="auth-label">Contraseña
        <span class="auth-input-wrap"><span>*</span><input class="auth-input" id="setupPassword" type="password" minlength="8" autocomplete="new-password" placeholder="8+ caracteres, mayúscula y número" required></span>
      </label>
      <label class="auth-label">Confirmar contraseña
        <span class="auth-input-wrap"><span>✓</span><input class="auth-input" id="setupConfirm" type="password" minlength="8" autocomplete="new-password" placeholder="Repite la contraseña" required></span>
      </label>
      <label class="auth-label">Cuenta de Google
        <span class="auth-input-wrap"><span>G</span><input class="auth-input" id="setupGoogle" type="email" placeholder="tucuenta@gmail.com" required></span>
      </label>
      <p class="auth-note">La contraseña se almacena de forma segura.</p>
      <div class="auth-error" id="authError"></div>
      <button class="auth-submit" id="authSubmit" type="submit">Crear cuenta e ingresar</button>
      <div class="auth-switch">Esta será la cuenta <strong>administradora</strong> inicial.</div>
    </form>`;

  document.getElementById('setupForm').addEventListener('submit', crearCuenta);
}

async function crearCuenta(event) {
  event.preventDefault();
  setAuthError('');

  const username = document.getElementById('setupUser').value.trim();
  const password = document.getElementById('setupPassword').value;
  const confirmPassword = document.getElementById('setupConfirm').value;
  const googleEmail = document.getElementById('setupGoogle').value.trim();

  if (password !== confirmPassword) {
    setAuthError('Las contraseñas no coinciden.');
    return;
  }

  setAuthBusy(true, 'Creando cuenta…');

  try {
    const data = await publicApi('/api/auth/setup', {
      method: 'POST',
      body: { username, password, googleEmail }
    });

    localStorage.setItem(USER_KEY, username);
    saveToken(data.token);
    iniciarAplicacion(data.user, data.config);
  } catch (error) {
    setAuthError(error.message);
    setAuthBusy(false);
  }
}

function renderLogin() {
  clearInterval(lockTimer);
  const lastUser = localStorage.getItem(USER_KEY) || '';

  authCard.innerHTML = `
    <h1>Iniciar sesión</h1>
    <p class="auth-subtitle">Ingresa tus datos para continuar.</p>
    <div class="auth-divider"></div>
    <form class="auth-form" id="loginForm">
      <label class="auth-label">Usuario
        <span class="auth-input-wrap"><span>U</span><input class="auth-input" id="loginUser" maxlength="30" value="${esc(lastUser)}" autocomplete="username" placeholder="Tu usuario" required></span>
      </label>
      <label class="auth-label">Contraseña
        <span class="auth-input-wrap"><span>*</span><input class="auth-input" id="loginPassword" type="password" autocomplete="current-password" placeholder="Tu contraseña" required></span>
      </label>
      <div class="auth-error" id="authError"></div>
      <button class="auth-submit" id="authSubmit" type="submit">Iniciar sesión</button>
      <button class="auth-link-button" type="button" onclick="renderRegister()">Crear cuenta</button>
      
    </form>`;

  document.getElementById('loginForm').addEventListener('submit', iniciarSesion);
  setTimeout(() => document.getElementById(lastUser ? 'loginPassword' : 'loginUser')?.focus(), 50);
}

function renderRegister() {
  clearInterval(lockTimer);
  authCard.innerHTML = `
    
    <h1>Registrarse</h1>
    <p class="auth-subtitle">Completa los datos para crear una cuenta.</p>
    <div class="auth-divider"></div>
    <form class="auth-form" id="registerForm">
      <label class="auth-label">Nombre de usuario
        <span class="auth-input-wrap"><span>U</span><input class="auth-input" id="registerUser" maxlength="30" autocomplete="username" placeholder="usuario.ejemplo" required></span>
      </label>
      <label class="auth-label">Correo electrónico
        <span class="auth-input-wrap"><span>@</span><input class="auth-input" id="registerEmail" type="email" autocomplete="email" placeholder="correo@ejemplo.com" required></span>
      </label>
      <label class="auth-label">Contraseña
        <span class="auth-input-wrap"><span>●</span><input class="auth-input" id="registerPassword" type="password" minlength="8" autocomplete="new-password" placeholder="8+ caracteres, mayúscula y número" required></span>
      </label>
      <label class="auth-label">Confirmar contraseña
        <span class="auth-input-wrap"><span>✓</span><input class="auth-input" id="registerConfirm" type="password" minlength="8" autocomplete="new-password" placeholder="Repite la contraseña" required></span>
      </label>
      <p class="auth-note">Usa al menos 8 caracteres, una mayúscula y un número.</p>
      <div class="auth-error" id="authError"></div>
      <button class="auth-submit" id="authSubmit" type="submit">Crear cuenta</button>
      <button class="auth-link-button" type="button" onclick="renderLogin()">Volver al inicio de sesión</button>
    </form>`;
  document.getElementById('registerForm').addEventListener('submit', registrarUsuario);
}

async function registrarUsuario(event) {
  event.preventDefault();
  setAuthError('');
  const username = document.getElementById('registerUser').value.trim();
  const googleEmail = document.getElementById('registerEmail').value.trim();
  const password = document.getElementById('registerPassword').value;
  const confirmPassword = document.getElementById('registerConfirm').value;
  if (password !== confirmPassword) return setAuthError('Las contraseñas no coinciden.');
  setAuthBusy(true, 'Creando cuenta…');
  try {
    await publicApi('/api/auth/register', { method: 'POST', body: { username, googleEmail, password } });
    localStorage.setItem(USER_KEY, username);
    renderLogin();
    setTimeout(() => setAuthError('Cuenta creada correctamente. Inicia sesión con tus credenciales.'), 0);
  } catch (error) {
    setAuthError(error.message);
    setAuthBusy(false);
  }
}

async function iniciarSesion(event) {
  event.preventDefault();
  setAuthError('');

  const username = document.getElementById('loginUser').value.trim();
  const password = document.getElementById('loginPassword').value;
  setAuthBusy(true, 'Verificando…');

  try {
    const data = await publicApi('/api/auth/login', {
      method: 'POST',
      body: { username, password }
    });

    localStorage.setItem(USER_KEY, username);
    saveToken(data.token);
    iniciarAplicacion(data.user, data.config);
  } catch (error) {
    if (error.status === 423 && error.data?.locked) {
      startLockout(error.data.remainingSeconds || 28);
      return;
    }

    const attempts = error.data?.attemptsRemaining;
    const suffix = Number.isFinite(attempts) ? ` Te quedan ${attempts} intento(s).` : '';
    setAuthError(error.message + suffix);
    setAuthBusy(false);
  }
}

function formatSeconds(seconds) {
  return `00:${String(Math.max(0, seconds)).padStart(2, '0')}`;
}

function startLockout(initialSeconds = 28) {
  clearInterval(lockTimer);
  let remaining = Math.max(0, Number(initialSeconds) || 28);

  authCard.innerHTML = `
    <h1>Cuenta bloqueada<br>temporalmente</h1>
    <div class="auth-divider"></div>
    <p class="auth-subtitle">Has alcanzado el límite de intentos.<br>Espera <strong id="lockInline">${formatSeconds(remaining)}</strong> para continuar.</p>
    <div class="lockout-box">
      <div class="hourglass" aria-hidden="true">⌛</div>
      <div class="lockout-time" id="lockTime">${formatSeconds(remaining)}</div>
      <button class="lockout-button" id="retryLogin" type="button" disabled>Reintentar</button>
    </div>`;

  const time = document.getElementById('lockTime');
  const inline = document.getElementById('lockInline');
  const retry = document.getElementById('retryLogin');
  retry.addEventListener('click', renderLogin);

  lockTimer = setInterval(() => {
    remaining -= 1;
    const value = formatSeconds(remaining);
    time.textContent = value;
    inline.textContent = value;

    if (remaining <= 0) {
      clearInterval(lockTimer);
      retry.disabled = false;
      retry.textContent = 'Reintentar ahora';
    }
  }, 1000);
}

function iniciarAplicacion(user, config) {
  usuarioActual = user;
  applyConfig(config);
  showApp();

  document.getElementById('profileName').textContent = user.username;
  document.getElementById('profileAvatar').textContent = user.username.slice(0, 1).toUpperCase();
  document.getElementById('profileRole').textContent = user.role === 'admin' ? 'Administrador' : 'Usuario';
  document.getElementById('sessionInfo').textContent = `Sesión de ${user.username}`;
  document.querySelectorAll('.admin-only').forEach(el => el.classList.toggle('hidden', user.role !== 'admin'));

  activarMenu('inicio');
  inicio();
  testBackend(false);
}

async function cerrarSesion() {
  try {
    await api('/api/auth/logout', { method: 'POST' });
  } catch (_) {
    // Aunque el backend no responda, se cierra la sesión local.
  }

  clearToken();
  usuarioActual = null;
  showAuth();
  renderLogin();
}

async function initAuth() {
  showAuth();

  try {
    const status = await publicApi('/api/auth/status');
    applyConfig(status.config);

    if (status.setupRequired) {
      clearToken();
      renderSetup();
      return;
    }

    if (getToken()) {
      try {
        const session = await api('/api/auth/me');
        iniciarAplicacion(session.user, session.config);
        return;
      } catch (_) {
        clearToken();
      }
    }

    if (status.locked) {
      startLockout(status.remainingSeconds || 28);
    } else {
      renderLogin();
    }
  } catch (error) {
    authCard.innerHTML = `
      <h1>No se pudo iniciar</h1>
      <p class="auth-subtitle">El frontend no logra conectarse con el backend en <strong>${esc(API_URL)}</strong>.</p>
      <div class="auth-error show">${esc(error.message)}</div>
      <button class="auth-submit" type="button" onclick="initAuth()">Volver a intentar</button>`;
  }
}

function activarMenu(section) {
  document.querySelectorAll('.menu-item').forEach(button => {
    button.classList.toggle('active', button.dataset.section === section);
  });
}

document.querySelectorAll('.menu-item').forEach(button => {
  button.addEventListener('click', () => {
    activarMenu(button.dataset.section);
    cargar(button.dataset.section);
  });
});

async function testBackend(showAlert = true) {
  try {
    const data = await request('/api/health', {}, false);
    document.getElementById('apiStatus').textContent = `Activo: ${data.estado}`;
    if (showAlert) alert('Backend activo correctamente');
  } catch (error) {
    document.getElementById('apiStatus').textContent = 'No conecta';
    if (showAlert) alert(`No conecta backend: ${error.message}`);
  }
}

function badge(risk) {
  return `<span class="badge ${esc(risk)}">${esc(risk)}</span>`;
}

function visual(data = {}) {
  return `
    <div class="mini-grid">
      <div class="mini-card"><strong>Páginas</strong><span>${esc(data.paginas ?? '-')}</span></div>
      <div class="mini-card"><strong>Imágenes</strong><span>${esc(data.imagenes_detectadas ?? 0)}</span></div>
      <div class="mini-card"><strong>Tablas</strong><span>${esc(data.tablas_detectadas ?? 0)}</span></div>
      <div class="mini-card"><strong>OCR</strong><span>${data.ocr_aplicado ? 'Sí' : 'No'}</span></div>
      <div class="mini-card"><strong>Palabras</strong><span>${esc(data.palabras_extraidas ?? 0)}</span></div>
      <div class="mini-card"><strong>Caracteres</strong><span>${esc(data.caracteres_extraidos ?? 0)}</span></div>
    </div>
    <p class="muted">${esc(data.resumen_visual || '')}</p>`;
}

function rowsBar(items = []) {
  const max = Math.max(...items.map(item => Number(item.similitud || item.valor || 0)), 1);

  return items.map(item => {
    const value = Number(item.similitud || item.valor || 0);
    const label = item.documento || item.etiqueta || '';
    return `
      <div class="bar-row">
        <span title="${esc(label)}">${esc(label)}</span>
        <div class="bar-track"><b style="width:${(value / max) * 100}%"></b></div>
        <em>${value.toFixed(1)}%</em>
      </div>`;
  }).join('');
}

function cargar(section) {
  if (section === 'inicio') inicio();
  if (section === 'subir') subir();
  if (section === 'base') bases();
  if (section === 'resultados') resultados();
  if (section === 'reportes') reportes();
  if (section === 'historial') historial();
  if (section === 'borrados') borrados();
  if (section === 'papelera') papelera();
  if (section === 'estadisticas') estadisticas();
  if (section === 'usuarios') usuarios();
  if (section === 'perfil') perfil();
  if (section === 'configuracion') configuracion();
}

async function inicio() {
  let stats = { resumen: { totalAnalizados: 0, promedioSimilitud: 0, criticos: 0 }, bases: 0 };
  try { stats = await api('/api/estadisticas'); } catch (_) {}

  contenido.innerHTML = `
    <div class="cards">
      <div class="card"><div class="icon purple">📄</div><h3>Análisis activos</h3><div class="number">${stats.resumen.totalAnalizados}</div><small>Total procesado</small></div>
      <div class="card"><div class="icon blue">📚</div><h3>Documentos base</h3><div class="number">${stats.bases}</div><small>Bases activas</small></div>
      <div class="card"><div class="icon green">📊</div><h3>Similitud promedio</h3><div class="number">${stats.resumen.promedioSimilitud}%</div><small>Promedio actual</small></div>
      <div class="card"><div class="icon red">🗑️</div><h3>Papelera</h3><div class="number">ON</div><small>Restaurar borrados</small></div>
    </div>
    <div class="grid-2">
      <div class="section-card">
        <h3>Flujo del sistema</h3>
        <div class="steps">
          <div class="step">1. Sube documentos base en PDF, Word, TXT o imagen.</div>
          <div class="step">2. Sube el archivo que quieres analizar.</div>
          <div class="step">3. El sistema extrae texto, tablas e imágenes con OCR.</div>
          <div class="step">4. El motor C++ calcula similitud con Rabin-Karp + Winnowing.</div>
          <div class="step">5. Puedes borrar y restaurar desde Papelera.</div>
        </div>
      </div>
      <div class="section-card"><h3>Últimos análisis</h3><div id="lastHist" class="muted">Cargando...</div></div>
    </div>`;

  try {
    const history = await api('/api/historial');
    document.getElementById('lastHist').innerHTML = history.length
      ? `<table class="table"><tbody>${history.slice(0, 5).map(item => `<tr><td>${esc(item.documento)}</td><td>${Number(item.resultadoGeneral).toFixed(2)}%</td><td>${badge(item.nivelRiesgo)}</td></tr>`).join('')}</tbody></table>`
      : 'Aún no hay análisis.';
  } catch (_) {}
}

function subir() {
  contenido.innerHTML = `
    <div class="grid-2">
      <div class="section-card">
        <h3>Subir documento para analizar</h3>
        <div class="upload-box">
          <h2>📤 Cargar archivo</h2>
          <p>TXT, PDF, DOCX, PNG, JPG, JPEG, BMP, TIFF</p>
          <input id="archivo" type="file" accept=".txt,.pdf,.docx,.png,.jpg,.jpeg,.bmp,.tiff"><br>
          <button class="btn" onclick="analizar()">Analizar documento</button>
          <p class="status" id="estado">Esperando archivo...</p>
          <div class="progress"><span id="barra"></span></div>
        </div>
        <div id="resultadoRapido"></div>
      </div>
      <div class="section-card"><h3>Antes de analizar</h3><p class="muted">Primero agrega documentos base desde la sección Documentos Base. El archivo subido aquí se comparará contra esas bases.</p></div>
    </div>`;
}

async function analizar() {
  const input = document.getElementById('archivo');
  const estado = document.getElementById('estado');
  const barra = document.getElementById('barra');
  const output = document.getElementById('resultadoRapido');

  if (!input.files.length) {
    estado.textContent = 'Selecciona un archivo.';
    return;
  }

  const form = new FormData();
  form.append('documento', input.files[0]);
  estado.textContent = 'Procesando documento...';
  barra.style.width = '35%';
  output.innerHTML = '';

  try {
    const data = await api('/api/analizar', { method: 'POST', body: form });
    barra.style.width = '100%';
    estado.textContent = 'Análisis completado.';
    ultimoResultado = data;
    output.innerHTML = resultadoHTML(data);
  } catch (error) {
    barra.style.width = '0%';
    estado.textContent = `Error: ${error.message}`;
  }
}

function resultadoHTML(data) {
  const rows = (data.comparaciones || []).map(item => `
    <tr><td>${esc(item.documento)}</td><td>${Number(item.similitud).toFixed(2)}%</td><td>${esc(item.coincidencias)}</td><td>${badge(item.riesgo)}</td></tr>`).join('');

  return `
    <div class="result-box">
      <h3>Resultado del análisis</h3>
      <p>Documento: <strong>${esc(data.documentoAnalizado)}</strong></p>
      <div class="result-main">${Number(data.resultadoGeneral).toFixed(2)}%</div>
      <p>Riesgo: ${badge(data.nivelRiesgo)}</p>
      <p>Motor: <strong>${esc(data.motor)}</strong></p>
      <h4>Análisis visual</h4>${visual(data.visual)}
      <h4>Comparaciones</h4>
      <table class="table"><thead><tr><th>Documento base</th><th>Similitud</th><th>Coincidencias</th><th>Riesgo</th></tr></thead><tbody>${rows || '<tr><td colspan="4">No hay documentos base.</td></tr>'}</tbody></table>
      <div class="inline-actions"><button class="btn" onclick="activarMenu('reportes');cargar('reportes')">Ver reporte</button><button class="btn btn-secondary" onclick="activarMenu('historial');cargar('historial')">Historial</button></div>
    </div>`;
}

async function bases() {
  contenido.innerHTML = `
    <div class="section-card">
      <div class="section-head"><div><h3>Documentos Base</h3><p class="muted">Aquí puedes subir archivos base en PDF, DOCX, TXT o imágenes. Se guardan procesados para comparar.</p></div></div>
      <div class="upload-box">
        <h2>📚 Agregar documento base</h2>
        <input id="baseFile" type="file" accept=".txt,.pdf,.docx,.png,.jpg,.jpeg,.bmp,.tiff"><br>
        <button class="btn" onclick="subirBase()">Subir base</button>
        <p class="status" id="baseEstado">Esperando archivo...</p>
      </div>
      <div id="tablaBases">Cargando...</div>
    </div>`;
  await cargarBases();
}

async function subirBase() {
  const input = document.getElementById('baseFile');
  const estado = document.getElementById('baseEstado');

  if (!input.files.length) {
    estado.textContent = 'Selecciona un archivo base.';
    return;
  }

  const form = new FormData();
  form.append('documento', input.files[0]);
  estado.textContent = 'Subiendo y procesando base...';

  try {
    await api('/api/documentos-base', { method: 'POST', body: form });
    estado.textContent = 'Base agregada correctamente.';
    input.value = '';
    await cargarBases();
  } catch (error) {
    estado.textContent = `Error: ${error.message}`;
  }
}

async function cargarBases() {
  try {
    const basesList = await api('/api/documentos-base');
    document.getElementById('tablaBases').innerHTML = `
      <table class="table">
        <thead><tr><th>Nombre</th><th>Tipo</th><th>Palabras</th><th>Visual</th><th>Acción</th></tr></thead>
        <tbody>${basesList.map(item => `<tr><td>${esc(item.nombre)}</td><td>${esc(item.tipo)}</td><td>${esc(item.palabras)}</td><td>${esc(item.visual?.imagenes_detectadas || 0)} img / ${esc(item.visual?.tablas_detectadas || 0)} tablas</td><td><button class="btn btn-danger btn-small" onclick="borrarBase('${esc(item.id)}')">Enviar a papelera</button></td></tr>`).join('') || '<tr><td colspan="5">No hay bases activas.</td></tr>'}</tbody>
      </table>`;
  } catch (error) {
    document.getElementById('tablaBases').textContent = `No se pudo cargar: ${error.message}`;
  }
}

async function borrarBase(id) {
  if (!confirm('¿Enviar esta base a la papelera?')) return;
  await api(`/api/documentos-base/${encodeURIComponent(id)}`, { method: 'DELETE' });
  await cargarBases();
}

function resultados() {
  contenido.innerHTML = ultimoResultado
    ? resultadoHTML(ultimoResultado)
    : '<div class="section-card"><h3>Resultados</h3><p>No hay resultado reciente.</p><br><button class="btn" onclick="activarMenu(\'subir\');cargar(\'subir\')">Subir documento</button></div>';
}

function reportes() {
  if (!ultimoResultado) {
    contenido.innerHTML = '<div class="section-card"><h3>Reportes</h3><p>No hay análisis reciente.</p></div>';
    return;
  }

  const data = ultimoResultado;
  contenido.innerHTML = `
    <div class="section-card">
      <div class="section-head no-print"><div><h3>Reporte visual</h3><p class="muted">Este reporte se puede guardar como PDF.</p></div><button class="btn" onclick="window.print()">Guardar como PDF</button></div>
      <div class="report-visual">
        <div class="report-head"><div><h2>${esc(configuracionActual.appName)} · Reporte de análisis</h2><p>${esc(data.documentoAnalizado)}</p></div><div class="score">${Number(data.resultadoGeneral).toFixed(2)}%</div></div>
        <p>Riesgo: ${badge(data.nivelRiesgo)}</p>
        ${visual(data.visual)}
        <h4>Gráfico de similitud</h4>${rowsBar(data.comparaciones || [])}
        <h4>Detalle</h4>
        <table class="table"><tbody>${(data.comparaciones || []).map(item => `<tr><td>${esc(item.documento)}</td><td>${Number(item.similitud).toFixed(2)}%</td><td>${badge(item.riesgo)}</td></tr>`).join('')}</tbody></table>
      </div>
    </div>`;
}

async function historial() {
  contenido.innerHTML = '<div class="section-card"><h3>Historial de análisis</h3><div id="hist">Cargando...</div></div>';

  try {
    const history = await api('/api/historial');
    document.getElementById('hist').innerHTML = `
      <table class="table">
        <thead><tr><th>Fecha</th><th>Documento</th><th>Tipo</th><th>Resultado</th><th>Riesgo</th><th>Acción</th></tr></thead>
        <tbody>${history.map(item => `<tr><td>${new Date(item.fecha).toLocaleString()}</td><td>${esc(item.documento)}</td><td>${esc(item.tipoDocumento)}</td><td>${Number(item.resultadoGeneral).toFixed(2)}%</td><td>${badge(item.nivelRiesgo)}</td><td><button class="btn btn-danger btn-small" onclick="borrarAnalisis('${esc(item.id)}')">Borrar</button></td></tr>`).join('') || '<tr><td colspan="6">Sin historial.</td></tr>'}</tbody>
      </table>`;
  } catch (error) {
    document.getElementById('hist').textContent = error.message;
  }
}

async function borrarAnalisis(id) {
  if (!confirm('¿Enviar análisis a papelera?')) return;
  await api(`/api/historial/${encodeURIComponent(id)}`, { method: 'DELETE' });
  historial();
}

async function borrados() {
  contenido.innerHTML = '<div class="section-card"><h3>Análisis borrados</h3><div id="borrados">Cargando...</div></div>';

  try {
    const deleted = await api('/api/analisis-borrados');
    document.getElementById('borrados').innerHTML = `
      <table class="table">
        <thead><tr><th>Documento</th><th>Resultado</th><th>Fecha borrado</th><th>Acción</th></tr></thead>
        <tbody>${deleted.map(item => `<tr><td>${esc(item.documento)}</td><td>${Number(item.resultadoGeneral).toFixed(2)}%</td><td>${item.deletedAt ? new Date(item.deletedAt).toLocaleString() : '-'}</td><td><button class="btn btn-small" onclick="restaurarAnalisis('${esc(item.id)}')">Restaurar</button></td></tr>`).join('') || '<tr><td colspan="4">No hay análisis borrados.</td></tr>'}</tbody>
      </table>`;
  } catch (error) {
    document.getElementById('borrados').textContent = error.message;
  }
}

async function restaurarAnalisis(id) {
  await api(`/api/papelera/analisis/${encodeURIComponent(id)}/restaurar`, { method: 'POST' });
  borrados();
}

async function papelera() {
  contenido.innerHTML = '<div class="section-card"><h3>Papelera</h3><p class="muted">Aquí puedes restaurar bases y análisis borrados o eliminarlos definitivamente.</p><br><div id="trash">Cargando...</div></div>';

  try {
    const trash = await api('/api/papelera');
    document.getElementById('trash').innerHTML = `
      <h4>Bases borradas</h4>
      <table class="table"><tbody>${trash.bases.map(item => `<tr><td>${esc(item.nombre)}</td><td>${esc(item.tipo)}</td><td><button class="btn btn-small" onclick="restaurarBase('${esc(item.id)}')">Restaurar</button> <button class="btn btn-danger btn-small" onclick="eliminarPermanente('base','${esc(item.id)}')">Eliminar</button></td></tr>`).join('') || '<tr><td>Sin bases en papelera.</td></tr>'}</tbody></table>
      <br><h4>Análisis borrados</h4>
      <table class="table"><tbody>${trash.analisis.map(item => `<tr><td>${esc(item.documento)}</td><td>${Number(item.resultadoGeneral).toFixed(2)}%</td><td><button class="btn btn-small" onclick="restaurarAnalisisPapelera('${esc(item.id)}')">Restaurar</button> <button class="btn btn-danger btn-small" onclick="eliminarPermanente('analisis','${esc(item.id)}')">Eliminar</button></td></tr>`).join('') || '<tr><td>Sin análisis en papelera.</td></tr>'}</tbody></table>`;
  } catch (error) {
    document.getElementById('trash').textContent = error.message;
  }
}

async function restaurarBase(id) {
  await api(`/api/papelera/base/${encodeURIComponent(id)}/restaurar`, { method: 'POST' });
  papelera();
}

async function restaurarAnalisisPapelera(id) {
  await api(`/api/papelera/analisis/${encodeURIComponent(id)}/restaurar`, { method: 'POST' });
  papelera();
}

async function eliminarPermanente(type, id) {
  if (!confirm('Esto eliminará definitivamente. ¿Continuar?')) return;
  await api(`/api/papelera/${encodeURIComponent(type)}/${encodeURIComponent(id)}`, { method: 'DELETE' });
  papelera();
}

async function estadisticas() {
  contenido.innerHTML = '<div class="section-card"><h3>Estadísticas</h3><div id="stats">Cargando...</div></div>';

  try {
    const stats = await api('/api/estadisticas');
    const values = Object.entries(stats.resumen.riesgo || {}).map(([key, value]) => ({ etiqueta: key, valor: value }));
    document.getElementById('stats').innerHTML = `
      <div class="cards">
        <div class="card"><h3>Total</h3><div class="number">${stats.resumen.totalAnalizados}</div></div>
        <div class="card"><h3>Promedio</h3><div class="number">${stats.resumen.promedioSimilitud}%</div></div>
        <div class="card"><h3>Críticos</h3><div class="number">${stats.resumen.criticos}</div></div>
        <div class="card"><h3>Bases</h3><div class="number">${stats.bases}</div></div>
      </div>
      <h4>Distribución de riesgo</h4>${rowsBar(values)}`;
  } catch (error) {
    document.getElementById('stats').textContent = error.message;
  }
}

async function usuarios() {
  if (usuarioActual?.role !== 'admin') return inicio();
  contenido.innerHTML = '<div class="section-card"><h3>Administración de usuarios</h3><p class="muted">Consulta las cuentas registradas y el uso del sistema.</p><div id="usersAdmin" style="margin-top:18px">Cargando...</div></div>';
  try {
    const data = await api('/api/admin/users');
    document.getElementById('usersAdmin').innerHTML = `
      <div class="cards user-stats">
        <div class="card"><h3>Total registrados</h3><div class="number">${data.stats.total}</div></div>
        <div class="card"><h3>Administradores</h3><div class="number">${data.stats.admins}</div></div>
        <div class="card"><h3>Usuarios</h3><div class="number">${data.stats.regular}</div></div>
        <div class="card"><h3>Cuentas activas</h3><div class="number">${data.stats.active}</div></div>
      </div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Usuario</th><th>Correo</th><th>Rol</th><th>Registro</th><th>Último acceso</th></tr></thead>
        <tbody>${data.users.map(u => `<tr><td><strong>${esc(u.username)}</strong></td><td>${esc(u.googleEmail)}</td><td><span class="role-badge ${u.role}">${u.role === 'admin' ? 'Administrador' : 'Usuario'}</span></td><td>${u.createdAt ? new Date(u.createdAt).toLocaleString() : '-'}</td><td>${u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : 'Sin acceso'}</td></tr>`).join('')}</tbody>
      </table></div>`;
  } catch (error) {
    document.getElementById('usersAdmin').textContent = error.message;
  }
}

function configuracion() {
  if (usuarioActual?.role !== 'admin') return inicio();
  const tones = [
    ['violet', 'Violeta'],
    ['blue', 'Azul'],
    ['green', 'Verde'],
    ['orange', 'Naranja'],
    ['pink', 'Rosa']
  ];

  contenido.innerHTML = `
    <div class="settings-grid">
      <div class="section-card">
        <h3>Personalización del programa</h3>
        <form class="settings-form" id="settingsForm">
          <div class="form-field">
            <label for="appNameInput">Nombre del programa</label>
            <input class="form-control" id="appNameInput" maxlength="40" value="${esc(configuracionActual.appName)}" required>
            <p class="muted">El nombre aparecerá en el menú, la cabecera y los reportes.</p>
          </div>
          <div class="form-field">
            <label>Tono de la interfaz</label>
            <div class="tone-options">
              ${tones.map(([value, label]) => `
                <label class="tone-option">
                  <input type="radio" name="tone" value="${value}" ${configuracionActual.tone === value ? 'checked' : ''}>
                  <span class="tone-chip"><span class="tone-dot tone-${value}"></span>${label}</span>
                </label>`).join('')}
            </div>
          </div>
          <div class="inline-actions"><button class="btn" type="submit">Guardar cambios</button><button class="btn btn-secondary" type="button" onclick="restaurarVistaConfig()">Cancelar vista previa</button></div>
          <p class="settings-message" id="settingsMessage"></p>
        </form>
      </div>
      <div class="section-card">
        <h3>Cuenta de acceso</h3>
        <div class="account-line"><span>Usuario</span><strong>${esc(usuarioActual?.username || '-')}</strong></div>
        <div class="account-line"><span>Cuenta Google</span><strong>${esc(usuarioActual?.googleEmail || '-')}</strong></div>
        <div class="account-line"><span>Rol</span><strong>${usuarioActual?.role === 'admin' ? 'Administrador' : 'Usuario'}</strong></div>
        <p class="auth-note" style="margin-top:16px">La cuenta Google se muestra únicamente como parte de la demostración del sistema.</p>
      </div>
    </div>`;

  document.getElementById('settingsForm').addEventListener('submit', guardarConfiguracion);
  document.querySelectorAll('input[name="tone"]').forEach(radio => {
    radio.addEventListener('change', () => {
      document.body.dataset.tone = radio.value;
    });
  });
}

function restaurarVistaConfig() {
  document.body.dataset.tone = configuracionActual.tone;
  configuracion();
}

async function guardarConfiguracion(event) {
  event.preventDefault();
  const message = document.getElementById('settingsMessage');
  const button = event.submitter;
  const appName = document.getElementById('appNameInput').value.trim();
  const tone = document.querySelector('input[name="tone"]:checked')?.value || configuracionActual.tone;

  button.disabled = true;
  message.textContent = 'Guardando...';

  try {
    const config = await api('/api/config', { method: 'PUT', body: { appName, tone } });
    applyConfig(config);
    message.textContent = 'Cambios guardados correctamente.';
  } catch (error) {
    document.body.dataset.tone = configuracionActual.tone;
    message.textContent = `Error: ${error.message}`;
  } finally {
    button.disabled = false;
  }
}


function formatDate(value) {
  return value ? new Date(value).toLocaleString() : 'Sin registro';
}

async function inicio() {
  contenido.innerHTML = '<div class="section-card"><h3>Resumen del sistema</h3><p class="muted">Cargando información...</p></div>';
  try {
    const data = await api('/api/dashboard');
    contenido.innerHTML = `
      <div class="cards dashboard-cards">
        <div class="card"><h3>Documentos analizados</h3><div class="number">${data.totalAnalizados}</div><small>Análisis disponibles</small></div>
        <div class="card"><h3>Documentos base</h3><div class="number">${data.documentosBase}</div><small>Archivos de comparación</small></div>
        <div class="card"><h3>Similitud promedio</h3><div class="number">${data.promedioSimilitud}%</div><small>Promedio general</small></div>
        <div class="card"><h3>${usuarioActual?.role === 'admin' ? 'Usuarios registrados' : 'Coincidencias'}</h3><div class="number">${usuarioActual?.role === 'admin' ? data.usuariosRegistrados : data.coincidenciasDetectadas}</div><small>${usuarioActual?.role === 'admin' ? 'Cuentas del sistema' : 'Coincidencias detectadas'}</small></div>
      </div>
      <div class="section-card">
        <div class="section-head"><div><h3>Últimos análisis</h3><p class="muted">Actividad reciente del sistema.</p></div><button class="btn btn-secondary" onclick="activarMenu('subir');cargar('subir')">Nuevo análisis</button></div>
        <div class="table-wrap"><table class="table"><thead><tr><th>Documento</th><th>Usuario</th><th>Resultado</th><th>Riesgo</th><th>Fecha</th></tr></thead>
        <tbody>${(data.recientes || []).map(item => `<tr><td>${esc(item.documento)}</td><td>${esc(item.userName || 'Anterior')}</td><td>${Number(item.resultadoGeneral || 0).toFixed(2)}%</td><td>${badge(item.nivelRiesgo)}</td><td>${formatDate(item.fecha)}</td></tr>`).join('') || '<tr><td colspan="5">Todavía no se realizaron análisis.</td></tr>'}</tbody></table></div>
      </div>`;
  } catch (error) {
    contenido.innerHTML = `<div class="section-card"><h3>Resumen del sistema</h3><p>${esc(error.message)}</p></div>`;
  }
}

async function usuarios(filtro = '') {
  if (usuarioActual?.role !== 'admin') return inicio();
  contenido.innerHTML = `<div class="section-card"><div class="section-head"><div><h3>Administración de usuarios</h3><p class="muted">Gestiona roles, estado y contraseñas.</p></div><input id="userSearch" class="form-control compact-input" placeholder="Buscar usuario o correo" value="${esc(filtro)}"></div><div id="usersAdmin">Cargando...</div></div>`;
  try {
    const data = await api('/api/admin/users');
    const q = filtro.trim().toLowerCase();
    const list = data.users.filter(u => !q || u.username.toLowerCase().includes(q) || u.googleEmail.toLowerCase().includes(q));
    document.getElementById('usersAdmin').innerHTML = `
      <div class="cards user-stats">
        <div class="card"><h3>Total</h3><div class="number">${data.stats.total}</div></div>
        <div class="card"><h3>Administradores</h3><div class="number">${data.stats.admins}</div></div>
        <div class="card"><h3>Usuarios</h3><div class="number">${data.stats.regular}</div></div>
        <div class="card"><h3>Activos</h3><div class="number">${data.stats.active}</div></div>
      </div>
      <div class="table-wrap"><table class="table"><thead><tr><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Último acceso</th><th>Acciones</th></tr></thead>
      <tbody>${list.map(u => `<tr><td><strong>${esc(u.username)}</strong><br><small>${formatDate(u.createdAt)}</small></td><td>${esc(u.googleEmail)}</td><td><select class="table-select" onchange="cambiarRol('${u.id}',this.value)" ${u.id === usuarioActual.id ? 'disabled' : ''}><option value="user" ${u.role === 'user' ? 'selected' : ''}>Usuario</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Administrador</option></select></td><td><span class="status-pill ${u.active ? 'active' : 'inactive'}">${u.active ? 'Activo' : 'Inactivo'}</span></td><td>${formatDate(u.lastLoginAt)}</td><td class="actions-cell"><button class="btn btn-small btn-secondary" onclick="cambiarEstadoUsuario('${u.id}',${!u.active})" ${u.id === usuarioActual.id ? 'disabled' : ''}>${u.active ? 'Desactivar' : 'Activar'}</button><button class="btn btn-small" onclick="restablecerClave('${u.id}','${esc(u.username)}')">Restablecer clave</button></td></tr>`).join('') || '<tr><td colspan="6">No hay coincidencias.</td></tr>'}</tbody></table></div>`;
    document.getElementById('userSearch').oninput = e => usuarios(e.target.value);
  } catch (error) { document.getElementById('usersAdmin').textContent = error.message; }
}

async function cambiarRol(id, role) {
  try { await api(`/api/admin/users/${encodeURIComponent(id)}`, { method:'PUT', body:{ role } }); await usuarios(document.getElementById('userSearch')?.value || ''); }
  catch (error) { alert(error.message); await usuarios(); }
}
async function cambiarEstadoUsuario(id, active) {
  try { await api(`/api/admin/users/${encodeURIComponent(id)}`, { method:'PUT', body:{ active } }); await usuarios(document.getElementById('userSearch')?.value || ''); }
  catch (error) { alert(error.message); }
}
async function restablecerClave(id, username) {
  const password = prompt(`Nueva contraseña temporal para ${username}:`);
  if (!password) return;
  try { await api(`/api/admin/users/${encodeURIComponent(id)}/password`, { method:'PUT', body:{ password } }); alert('Contraseña actualizada. Las sesiones anteriores fueron cerradas.'); }
  catch (error) { alert(error.message); }
}

function perfil() {
  contenido.innerHTML = `
    <div class="settings-grid">
      <div class="section-card"><h3>Datos del perfil</h3><form id="profileForm" class="settings-form">
        <div class="form-field"><label>Nombre de usuario</label><input id="profileUsername" class="form-control" value="${esc(usuarioActual.username)}" required></div>
        <div class="form-field"><label>Correo electrónico</label><input id="profileEmail" type="email" class="form-control" value="${esc(usuarioActual.googleEmail)}" required></div>
        <div class="account-line"><span>Rol</span><strong>${usuarioActual.role === 'admin' ? 'Administrador' : 'Usuario'}</strong></div>
        <div class="account-line"><span>Cuenta creada</span><strong>${formatDate(usuarioActual.createdAt)}</strong></div>
        <button class="btn" type="submit">Guardar perfil</button><p id="profileMessage" class="settings-message"></p>
      </form></div>
      <div class="section-card"><h3>Cambiar contraseña</h3><form id="passwordForm" class="settings-form">
        <div class="form-field"><label>Contraseña actual</label><input id="currentPassword" type="password" class="form-control" required></div>
        <div class="form-field"><label>Nueva contraseña</label><input id="newPassword" type="password" class="form-control" required></div>
        <div class="form-field"><label>Confirmar contraseña</label><input id="confirmPassword" type="password" class="form-control" required></div>
        <p class="muted">Mínimo 8 caracteres, una mayúscula, una minúscula y un número.</p>
        <button class="btn" type="submit">Cambiar contraseña</button><p id="passwordMessage" class="settings-message"></p>
      </form></div>
    </div>`;
  document.getElementById('profileForm').onsubmit = guardarPerfil;
  document.getElementById('passwordForm').onsubmit = cambiarClavePerfil;
}

async function guardarPerfil(e) {
  e.preventDefault(); const msg=document.getElementById('profileMessage');
  try { const data=await api('/api/profile',{method:'PUT',body:{username:profileUsername.value.trim(),googleEmail:profileEmail.value.trim()}}); usuarioActual=data.user; actualizarPerfil(); msg.textContent='Perfil actualizado correctamente.'; }
  catch(error){msg.textContent=error.message;}
}
async function cambiarClavePerfil(e) {
  e.preventDefault(); const msg=document.getElementById('passwordMessage');
  if(newPassword.value!==confirmPassword.value){msg.textContent='Las contraseñas no coinciden.';return;}
  try { await api('/api/profile/password',{method:'PUT',body:{currentPassword:currentPassword.value,newPassword:newPassword.value}}); e.target.reset(); msg.textContent='Contraseña actualizada correctamente.'; }
  catch(error){msg.textContent=error.message;}
}

function actualizarPerfil() {
  document.getElementById('profileName').textContent = usuarioActual?.username || 'Usuario';
  document.getElementById('profileRole').textContent = usuarioActual?.role === 'admin' ? 'Administrador' : 'Usuario';
  document.getElementById('profileAvatar').textContent = (usuarioActual?.username || 'U').charAt(0).toUpperCase();
}

function reporteDetalle(data) {
  const comps = data.comparaciones || [];
  return `
    <div class="report-summary-grid">
      <div class="mini-card"><span>Similitud general</span><strong>${Number(data.resultadoGeneral || 0).toFixed(2)}%</strong></div>
      <div class="mini-card"><span>Nivel</span><strong>${esc(data.nivelRiesgo || '-')}</strong></div>
      <div class="mini-card"><span>Fuentes comparadas</span><strong>${comps.length}</strong></div>
      <div class="mini-card"><span>Coincidencias</span><strong>${comps.reduce((n,c)=>n+Number(c.coincidencias||0),0)}</strong></div>
    </div>
    <div class="notice"><strong>Interpretación:</strong> el sistema identifica similitudes textuales. La determinación final de plagio requiere revisión humana.</div>
    <h4>Detalle por documento</h4>
    <div class="table-wrap"><table class="table"><thead><tr><th>Documento base</th><th>Similitud</th><th>Coincidencias</th><th>Nivel</th></tr></thead><tbody>${comps.map(c=>`<tr><td>${esc(c.documento)}</td><td>${Number(c.similitud||0).toFixed(2)}%</td><td>${Number(c.coincidencias||0)}</td><td>${badge(c.riesgo)}</td></tr>`).join('') || '<tr><td colspan="4">No se encontraron coincidencias.</td></tr>'}</tbody></table></div>`;
}

function reportes() {
  if (!ultimoResultado) { contenido.innerHTML='<div class="section-card"><h3>Reportes</h3><p>No hay un análisis reciente.</p></div>'; return; }
  const data=ultimoResultado;
  contenido.innerHTML=`<div class="section-card"><div class="section-head no-print"><div><h3>Reporte del análisis</h3><p class="muted">${esc(data.documentoAnalizado || data.documento)}</p></div><button class="btn" onclick="window.print()">Guardar como PDF</button></div><div class="report-visual"><div class="report-head"><div><h2>${esc(configuracionActual.appName)}</h2><p>Fecha: ${formatDate(data.fecha || new Date().toISOString())}</p><p>Analizado por: ${esc(data.userName || usuarioActual.username)}</p></div><div class="score">${Number(data.resultadoGeneral||0).toFixed(2)}%</div></div>${reporteDetalle(data)}${visual(data.visual)}</div></div>`;
}

async function verAnalisis(id) {
  try { const history=await api('/api/historial'); const item=history.find(x=>x.id===id); if(!item) throw new Error('Análisis no encontrado.'); ultimoResultado={...item,documentoAnalizado:item.documento}; activarMenu('reportes'); reportes(); }
  catch(error){alert(error.message);}
}

async function historial() {
  contenido.innerHTML='<div class="section-card"><h3>Historial de análisis</h3><div id="hist">Cargando...</div></div>';
  try { const history=await api('/api/historial'); document.getElementById('hist').innerHTML=`<div class="table-wrap"><table class="table"><thead><tr><th>Fecha</th><th>Documento</th><th>Usuario</th><th>Resultado</th><th>Riesgo</th><th>Acciones</th></tr></thead><tbody>${history.map(item=>`<tr><td>${formatDate(item.fecha)}</td><td>${esc(item.documento)}</td><td>${esc(item.userName||'Anterior')}</td><td>${Number(item.resultadoGeneral||0).toFixed(2)}%</td><td>${badge(item.nivelRiesgo)}</td><td class="actions-cell"><button class="btn btn-small" onclick="verAnalisis('${item.id}')">Ver reporte</button><button class="btn btn-danger btn-small" onclick="borrarAnalisis('${item.id}')">Borrar</button></td></tr>`).join('')||'<tr><td colspan="6">Sin historial.</td></tr>'}</tbody></table></div>`; }
  catch(error){document.getElementById('hist').textContent=error.message;}
}

initAuth();
